"""Loop with pedestrians scripts."""
